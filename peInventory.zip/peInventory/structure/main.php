<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../design/style.css?v=2">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CITE</title>
</head>

<body>
    <div class="header">
        <h1 class="head" id="head">CITE P.E. INVENTORY</h1>
        <img src="../pictures/citeLogo.png" class="citeLogo" alt="citeLogo">
    </div>
    
    <div class="form">
        <form action="../backend/controller/index.php" method="post">
            <input type="text" name="userName" class="cred" id="userName" placeholder="Username"><br>
            <input type="password" name="password" class="cred" id="password" placeholder="Password"><br>
            <input type="submit" name="login" id="login" class="cred" value="Login">
        </form>
    </div>

    <div class="prompt">
       
             <?php
             if (isset($_SESSION['error'])) {
                 echo '<p class="error">' . $_SESSION['error'] . '</p>';
                 unset($_SESSION['error']); // Clear the error message after displaying it
             }
             ?>
      
    </div>
</body>
</html>
