-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2024 at 12:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventorydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrowed_equipment`
--

CREATE TABLE `borrowed_equipment` (
  `id` int(11) NOT NULL,
  `equipment` varchar(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `student_id` varchar(255) NOT NULL,
  `borrow_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrowed_equipment`
--

INSERT INTO `borrowed_equipment` (`id`, `equipment`, `student_name`, `student_id`, `borrow_date`) VALUES
(1, 'Basketball', 'evj', '23334', '2024-06-10 05:44:38'),
(2, 'Volleyball', 'lester', 'diet  omad', '2024-06-10 05:55:16'),
(3, 'Basketball', 'lesteer', '989898', '2024-06-10 05:57:11'),
(4, 'Volleyball', 'vcv', 'dccxcx', '2024-06-10 06:17:12'),
(5, 'Soccer Ball', 'ffgddfc', 'fcdfcfccccdcd', '2024-06-10 06:17:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrowed_equipment`
--
ALTER TABLE `borrowed_equipment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrowed_equipment`
--
ALTER TABLE `borrowed_equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
