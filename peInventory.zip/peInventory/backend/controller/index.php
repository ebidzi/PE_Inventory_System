<?php
session_start();

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $userName = $_POST["userName"];
        $password = $_POST["password"];

        if(empty($userName) && empty($password)){
            $_SESSION["error"] = "Username and password is empty";
            header('Location: ../../structure/main.php');
            exit();
        }elseif(empty($userName)){
            $_SESSION["error"] = "Username is empty";
            header("Location: ../../structure/main.php");
            exit();
        }elseif(empty($password)){
            $_SESSION["error"] = "Password is empty";
            header("Location: ../../structure/main.php");
            exit();
        }elseif($userName === "admin" && $password === "admin"){
            header("Location: ../view/login.php");
            exit();
        }else{
            $_SESSION['error'] = 'Username or Password is not correct';
            header('Location: ../../structure/main.php');
            exit();
        }
           
    }
?>
