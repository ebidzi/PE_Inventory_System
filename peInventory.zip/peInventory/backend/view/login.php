<?php
session_start();


$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "inventorydb"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT COUNT(*) AS total_items FROM borrowed_equipment";
$result = $conn->query($sql);
$totalItems = 0;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalItems = $row["total_items"];
}


$sql_latest = "SELECT equipment, student_name FROM borrowed_equipment ORDER BY borrow_date DESC LIMIT 5";
$result_latest = $conn->query($sql_latest);
$latestItems = array();
if ($result_latest->num_rows > 0) {
    while($row_latest = $result_latest->fetch_assoc()) {
        $latestItems[] = $row_latest;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../design/nav.css?v=2">
    <link rel="stylesheet" href="../../design/dashboard.css?v=2">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <nav>
        <img src="../../pictures/citeLogo.png" class="citeLogo" alt="citeLogo">
        <h1 class="pe">P.E. EQUIPMENTS</h1>
        <a href="login.php" class="navs" id="dashboard">Dashboard</a>
        <a href="inventory.php" class="navs">Inventory</a>
        <a href="history.php" class="navs">History</a>
        <form action="login.php" method="post">
            <input type="submit" class="logout" name="logout" value="Logout">
        </form>
    </nav>

    <div class="content">


        <span class="heading">Welcome to the Dashboard</span>

       <p class="total">Total number of items in inventory: <?php echo $totalItems; ?></p>
 
     

        <span class="borrowed">Latest Borrowed Items</span>
        <ul>
            <?php foreach ($latestItems as $item): ?>
                <li><?php echo $item['equipment']; ?> - Borrowed by <?php echo $item['student_name']; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>

<?php
if (isset($_POST["logout"])) {
    session_destroy();
    header("Location: ../../structure/main.php");
    exit();
}
?>
