<?php
session_start();

// Database connection settings
$servername = "localhost"; // Update with your server details
$username = "root"; // Update with your database username
$password = ""; // Update with your database password
$dbname = "inventorydb"; // Use your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from POST request
    $equipment = $_POST['selectedEquipment'];
    $studentName = $_POST['studentName'];
    $studentId = $_POST['studentId'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO borrowed_equipment (equipment, student_name, student_id) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $equipment, $studentName, $studentId);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();

    // Redirect to a success page or back to the inventory page
    header("Location: inventory.php");
    exit();
}
?>
