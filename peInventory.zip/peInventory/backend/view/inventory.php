<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../design/nav.css?v=2">
    <link rel="stylesheet" href="../../design/inventory.css?v=1">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

</head>
<body>
    <nav>
        <img src="../../pictures/citeLogo.png" class="citeLogo" alt="citeLogo">
        <h1 class="pe">P.E. EQUIPMENTS</h1>
        <a href="login.php" class="navs" id="dashboard">Dashboard</a>
        <a href="inventory.php" class="navs" id="inventory">Inventory</a>
        <a href="history.php" class="navs" id="history">History</a>
        <form action="login.php" method="post">
            <input type="submit" class="logout" name="logout" value="Logout">
        </form>
    </nav>

    <div class="content">
        <form id="inventoryForm" action="process_borrow.php" method="post">
            <div class="equipment">
                <label for="basketball">BASKETBALL</label>
                <input type="button" class="borrow" value="Borrow" data-equipment="Basketball">
            </div>
            <div class="equipment">
                <label for="soccerball">SOCCER BALL</label>
                <input type="button" class="borrow" value="Borrow" data-equipment="Soccer Ball">
            </div>
            <div class="equipment">
                <label for="volleyball">VOLLEYBALL</label>
                <input type="button" class="borrow" value="Borrow" data-equipment="Volleyball">
            </div>
            <div class="equipment">
                <label for="tabletennisracket">TABLE-TENNIS RACKET</label>
                <input type="button" class="borrow" value="Borrow" data-equipment="Table-Tennis Racket">
            </div>
            <div class="equipment">
                <label for="badmintonracket">BADMINTON RACKET</label>
                <input type="button" class="borrow" value="Borrow" data-equipment="Badminton Racket">
            </div>
           
            <input type="hidden" name="selectedEquipment" id="selectedEquipment" value="">
        </form>
    </div>

  
    <div id="borrowModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <form id="borrowForm">
                <label for="studentName">Student Name:</label>
                <input type="text" id="studentName" name="studentName" required><br><br>
                <label for="studentId">Student ID:</label>
                <input type="text" id="studentId" name="studentId" required><br><br>
                <input type="button" value="Submit" id="submitBorrow">
            </form>
        </div>
    </div>

    <script>
        var modal = document.getElementById("borrowModal");
        var btns = document.getElementsByClassName("borrow");
        var span = document.getElementsByClassName("close")[0];

        var borrowForm = document.getElementById("borrowForm");
        var inventoryForm = document.getElementById("inventoryForm");
        var selectedEquipmentInput = document.getElementById("selectedEquipment");


        for (var i = 0; i < btns.length; i++) {
            btns[i].onclick = function() {
                selectedEquipmentInput.value = this.getAttribute('data-equipment');
                modal.style.display = "block";
            }
        }


        span.onclick = function() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        document.getElementById("submitBorrow").onclick = function() {
            var studentName = document.getElementById("studentName").value;
            var studentId = document.getElementById("studentId").value;

            var nameInput = document.createElement("input");
            nameInput.type = "hidden";
            nameInput.name = "studentName";
            nameInput.value = studentName;

            var idInput = document.createElement("input");
            idInput.type = "hidden";
            idInput.name = "studentId";
            idInput.value = studentId;

            inventoryForm.appendChild(nameInput);
            inventoryForm.appendChild(idInput);

            inventoryForm.submit();
        }
    </script>
</body>
</html>

<?php
if (isset($_POST["logout"])) {
    session_destroy();
    header("Location: ../../structure/main.php");
    exit();
}
?>
