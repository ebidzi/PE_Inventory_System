<?php
session_start();

$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "inventorydb"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT equipment, student_name, student_id, borrow_date FROM borrowed_equipment ORDER BY borrow_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../design/nav.css?v=2">
    <link rel="stylesheet" href="../../design/history.css?v=1">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <nav>
        <img src="../../pictures/citeLogo.png" class="citeLogo" alt="citeLogo">
        <h1 class="pe">P.E. EQUIPMENTS</h1>
        <a href="login.php" class="navs" id="dashboard">Dashboard</a>
        <a href="inventory.php" class="navs" id="inventory">Inventory</a>
        <a href="history.php" class="navs" id="history">History</a>
        <form action="login.php" method="post">
            <input type="submit" class="logout" name="logout" value="Logout">
        </form>
    </nav>

    <div class="content">
       <span class="borrowingHistory"> Borrowing History</span>
        <?php
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Equipment</th><th>Student Name</th><th>Student ID</th><th>Borrow Date</th></tr>";
    
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["equipment"]. "</td><td>" . $row["student_name"]. "</td><td>" . $row["student_id"]. "</td><td>" . $row["borrow_date"]. "</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No records found.";
        }
        $conn->close();
        ?>
    </div>
</body>
</html>

<?php
if (isset($_POST["logout"])) {
    session_destroy();
    header("Location: ../../structure/main.php");
    exit();
}
?>
